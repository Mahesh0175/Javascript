// while loop
/*
let n = prompt("Enter the value of n")
n = Number.parseInt(n)

let i = 0;
while(i<n){
  console.log(i)
  i++;
}
*/
// while loop
let n = prompt("Enter the value of n")
n = Number.parseInt(n)

let i = 10;
do{
  console.log(i)
  i++;
}while (i < n) 
