const regex = /(Harry){2}/gi
const text = "Harryharry is a very very nice awesome nice very boy"
console.log(text.replace(regex, "VERY"))