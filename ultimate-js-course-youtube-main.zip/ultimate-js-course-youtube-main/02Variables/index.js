console.log("This repl contains code for the Ultimate JavaScript course video no 2")
var a = 67 // a contains 67
console.log(a)
a = "harry"
console.log(a)
// let 8harry = 7 // Not allowed this will throw an error
// let var = 7