console.log("Note: View Files from this Repl to Access the Source Code")
console.log("This program adds 1, 2 and 54")

function addThreeNumbers(a, b, c) {
    return a + b + c;
}
let c = addThreeNumbers(1, 2, 54)
console.log(c)