first.className = "text-black red"
first.classList.add("red")
first.classList.remove("red")
first.classList.contains("red")
first.classList.toggle("red")