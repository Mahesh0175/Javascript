window.console.log(window)
console.log(document.body)
document.body.style.background = "yellow"