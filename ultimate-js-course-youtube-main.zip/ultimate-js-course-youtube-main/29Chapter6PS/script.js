// let number = prompt("Enter your number")
// number = Number.parseInt(number)

// if (number > 4) {
//   location.href = "https://google.com"
// }

let color = prompt("Enter the page background color")
document.body.style.background = color