// const {hello, ahello} = require("./module1") // commonjs
import harry, {hello, ahello} from "./module2.js";
hello()
ahello("Shivani")
ahello("Garima")
ahello("Nitika")
ahello("Aishwarya")
harry()